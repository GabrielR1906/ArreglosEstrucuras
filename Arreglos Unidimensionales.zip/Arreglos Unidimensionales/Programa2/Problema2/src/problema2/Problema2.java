package problema2;
import java.util.Scanner;
public class Problema2 {
    public static void main(String[] args) {
       Factorial f = new Factorial(); 
       Scanner entrada = new Scanner(System.in);
       int[] A = new int [10];
        for (int i = 0; i < A.length; i++) {
            System.out.println("Ingrese el valor para la posicion "+"["+i+"]");
            A[i] = entrada.nextInt();
        }
      f.setA(A);
      f.Pantalla();
      f.Factorial();
    }
    
}
