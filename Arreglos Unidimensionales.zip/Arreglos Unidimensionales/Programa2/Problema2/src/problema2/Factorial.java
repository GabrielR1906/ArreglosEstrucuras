package problema2;

public class Factorial {

    int[] A = new int[10];
    int[] B = new int[10];
    int factorial = 1;
    int aux = 0;
    String mensaje = "";
    public void Pantalla() {
        System.out.println("El arreglo es");
        for (int i = 0; i < A.length; i++) {
            mensaje = mensaje + A[i]+" ";
        }
        System.out.println("["+mensaje+"]");
    }

    public void Factorial() {
        for (int i = 0; i < A.length; i++) {
            for (int j = 0; j < A[i]; j++) {
                factorial = factorial * aux + 1;
                aux = aux + 1;
                B[i] = factorial;    
            }
            if (i == 0) {
                B[i]=1;
            }
            factorial = 1;
            aux = 0;
        }
        System.out.println("--------------------------------------------------");
        for (int i = 0; i < A.length; i++) {
            System.out.println("El factorial de " + A[i] + " es " + B[i]);
    }
        System.out.println("---------------------------------------------------");
    }

    
    public int[] getA() {
        return A;
    }

    public void setA(int[] A) {
        this.A = A;
    }

}
