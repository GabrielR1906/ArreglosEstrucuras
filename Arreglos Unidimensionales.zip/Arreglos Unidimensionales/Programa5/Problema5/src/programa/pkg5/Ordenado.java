/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programa.pkg5;

/**
 *
 * @author SALA H
 */
public class Ordenado {
    public void Comprobando(int[]A){
        for (int i = 0; i < A.length; i++) {
            if (A[i]<= A[i+1]) {
                System.out.println("El arreglo esta ordenado");
                break;
            }
            if (A[i]>A[i+1]) {
                System.out.println("El arreglo no esta ordenado");
                break;
            }
        }
    }
}
