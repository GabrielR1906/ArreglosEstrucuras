package programa.pkg5;

import java.util.Scanner;

public class Programa5 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Ordenado o = new Ordenado();
        
        System.out.println("Ingrese el tamano del arreglo");
        int []A = new int[entrada.nextInt()];
        
        for (int i = 0; i < A.length; i++) {
            System.out.println("Ingrese el valor de la posicion"+"["+i+"]");
            A[i]=entrada.nextInt();
        }
        
        o.Comprobando(A);
    }
    
}
