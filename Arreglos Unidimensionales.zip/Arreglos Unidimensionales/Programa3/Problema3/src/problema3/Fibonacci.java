package problema3;

public class Fibonacci {

    int[] A;
    int[] B = new int[10];
    int fibonacci = 0;
    int aux = 0;
    int aux2;

    public void Fibonaccil() {
        for (int i = 0; i < A.length; i++) {
            for (int j = 0; j < A[i]; j++) {
                 aux = A[i]-1;
                 aux2 = A[i]-2;
                 fibonacci= aux+aux2;
                B[i] = fibonacci;
            }
            if (i == 0) {
                B[i] = 0;
            }
            if (i==1||i==2) {
                B[i]=1;
            }
            
            fibonacci = 1;
            aux = 0;
        }
        System.out.println("--------------------------------------------------");
        for (int i = 0; i < A.length; i++) {
            System.out.println("El fibonacci de " + A[i] + " es " + B[i]);
        }
        System.out.println("---------------------------------------------------");
    }
    
    public int[] getA() {
        return A;
    }

    public void setA(int[] A) {
        this.A = A;
    }

}
