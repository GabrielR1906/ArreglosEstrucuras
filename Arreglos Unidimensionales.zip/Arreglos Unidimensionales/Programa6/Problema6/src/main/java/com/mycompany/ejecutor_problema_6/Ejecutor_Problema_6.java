package com.mycompany.ejecutor_problema_6;


import static com.mycompany.ejecutor_problema_6.Metodos.crearNuevoArreglo;
import static com.mycompany.ejecutor_problema_6.Metodos.generarArregloAleatorio;
import static com.mycompany.ejecutor_problema_6.Metodos.generarNumeroAleatorio;
import static com.mycompany.ejecutor_problema_6.Metodos.imprimirArreglo;
import java.util.Scanner;

public class Ejecutor_Problema_6 {

    public static void main(String[] args) {
        
         Scanner entrada = new Scanner(System.in);

        System.out.print("Ingrese el número de elementos del arreglo: ");
        int n = entrada.nextInt();

        int[] arregloT = generarArregloAleatorio(n);

        System.out.println("Arreglo T generado aleatoriamente:");
        imprimirArreglo(arregloT);

        System.out.print("Ingrese el índice del elemento por el cual desea dividir: ");
        int i = entrada.nextInt();

        int[] resultado = crearNuevoArreglo(arregloT, i);

        System.out.println("Arreglo resultado de la división:");
        imprimirArreglo(resultado);

        
    }

      
        
    }
        
    
        
        
        
    

