package com.mycompany.ejecutor_problema_6;

public class Metodos {
    
    public static int generarNumeroAleatorio() {
        int min = -100;
        int max = 100;

        return (int) (Math.random() * (max - min + 1) + min);
    }

    public static int[] crearNuevoArreglo(int[] arregloT, int i) {
        int n = arregloT.length;
        int divisor = arregloT[i];

        int[] resultado = new int[n];

        for (int j = 0; j < n; j++) {
            resultado[j] = arregloT[j] / divisor;
        }

        return resultado;
    }

    public static void imprimirArreglo(int[] arreglo) {
        int n = arreglo.length;

        for (int i = 0; i < n; i++) {
            System.out.print(arreglo[i] + " ");
        }

        System.out.println();
    }
    
    public static int[] generarArregloAleatorio(int n) {
        int[] arreglo = new int[n];

        for (int i = 0; i < n; i++) {
            int num = generarNumeroAleatorio();
            arreglo[i] = num;
        }

        return arreglo;
    }
}

    

    
   

    
   
    
    

