/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programa11;

import java.util.Scanner;

/**
 *
 * @author SALA H
 */
public class Programa11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Comparacion c = new Comparacion();
        String[] nombres = {"Pepe","Juan","Leonardo","Renato","Patricia",
            "Maria","Emma","Martina","Martina","Clara","Isabela"}; 
        
        c.Existente(nombres);
    }
    
}
