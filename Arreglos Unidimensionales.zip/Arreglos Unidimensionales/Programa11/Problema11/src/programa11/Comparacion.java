package programa11;

import java.util.Scanner;

public class Comparacion {

    Scanner entrada = new Scanner(System.in);

    public void Existente(String[] nombres) {
        boolean encontrado = false;
        String buscar;
        System.out.println("Ingrese el nombre a buscar");
        buscar = entrada.nextLine();
        buscar = buscar.toLowerCase();
        for (int i = 0; i < nombres.length; i++) {
            if (buscar.equals(nombres[i].toLowerCase())) {
                encontrado = true;
            }
        }
        
        if (encontrado == true) {
            System.out.println("El nombre si esta en la lista");
        }else{
            System.out.println("El nombre no esta en la lista");
        }

    }
}
