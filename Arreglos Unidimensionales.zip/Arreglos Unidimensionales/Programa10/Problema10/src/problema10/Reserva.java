package problema10;

import java.util.Scanner;

public class Reserva {

    Scanner entrada = new Scanner(System.in);
    //VARIABLES DE AYUDA
    int puestos;
    int puestofumador;
    int capacidadfumador = 0;
    int capacidadnormal = 0;
    int totalnormal;
    int totalfumador;
    int mensajetotalfumador = 0;
    int mensajetotalnormal = 0;
    //OPCIONES DE MENUS
    int opreserva;
    int opsalida;
    int opprincipal;
    int opreservamas;
    int opcancelacion;
    //ARREGLOS DE VUELO
    int[] vuelonormal = new int[70];
    int[] vuelofumadores = new int[30];
    //BANDERAS
    boolean banderareserva = true;
    boolean cancelarnormal = true;
    boolean cancelarfumador = true;

    //MENUPRINCIPAL
    public void menuprincipal() {
        System.out.println("-----------------MENU PRINCIPAL--------------------"+"\n"
                + "Reservar[1] "+"\n"
                + "Cancelar[2]"+"\n"
                + "Total de reservas[3]");
        System.out.println("---------------------------------------------------");
        opprincipal = entrada.nextInt();
        if (opprincipal == 1) {
            banderareserva = true;
            menureserva();
        }
        if (opprincipal == 2) {
            menucancelar();
        }
        if (opprincipal == 3) {
            TotalReservas();
        }

    }

    //MENURESERVAS
    public void menureserva() {
        while (banderareserva == true) {
            System.out.println("Su vuelo esta por salir "+"\n"
                    + "Si[1] "+"\n"
                    + "No[2]");
            opsalida = entrada.nextInt();
            if (opsalida == 1) {
                System.out.println("Su vuelo no se puede reservar porque esta por salir");
                menuprincipal();
            } else {
                System.out.println("----------------MENU DE RESERVA-----------------------");
                System.out.println("En que area quieres reservar "+"\n"
                        + "Normal[1]"+"\n"
                        + "Fumadores[2]");
                System.out.println("--------------------------------------------------");
                opreserva = entrada.nextInt();
                if (opreserva == 1) {
                    normal();
                } else {
                    fumador();
                }
                System.out.println("Quieres hacer alguna reserva mas?"+"\n"
                        + "Si[1]"+"\n"
                        + "No[2]");
                opreservamas = entrada.nextInt();
                if (opreservamas == 2) {
                    banderareserva = false;
                    menuprincipal();
                }
            }
        }
    }

    //MENUCANCELACION
    public void menucancelar() {
        System.out.println("-----------------------MENU DE CANCELACION------------------------");
        System.out.println("En que area quiere cancelar"+"\n"
                + "Normal[1]"+"\n"
                + "Fumadores[2]");
        System.out.println("--------------------------------------------------------------------------");
        opcancelacion = entrada.nextInt();
        if (opcancelacion == 1) {
            cancelarnormal = true;
            cancelarNormal();
        } else {
            cancelarfumador = true;
            cancelarFumador();
        }
    }
//PROCESO DE RESERVEVA CLASE NORMAL

    public void normal() {
        if (capacidadnormal <= vuelonormal.length) {
            System.out.println("[Ingrese la cantidad de reservas que quiere]");
            puestos = entrada.nextInt();
            for (int i = vuelonormal.length - puestos; i < vuelonormal.length; i++) {
                vuelonormal[i] = 1;
                capacidadnormal++;
            }
            mensajetotalnormal = mensajetotalnormal + puestos;
            System.out.println("-----------------------------------------------------------------------------");
            System.out.println("Su reserva se ha completado tiene " + mensajetotalnormal + " reservados de categoria "
                    + " [NORMAL]");
            totalnormal = vuelonormal.length - capacidadnormal;
            System.out.println("-----------------------------------------------------------------------------");
            System.out.println("La cantidad de puestos disponibles ahora son " + totalnormal);
        }
    }
//PROCESO DE RESERVA CLASE FUMADOR

    public void fumador() {
        if (capacidadfumador <= vuelofumadores.length) {
            System.out.println("Ingrese la cantidad de reservas que quiere");
            puestofumador = entrada.nextInt();
            for (int i = vuelofumadores.length - puestofumador; i < vuelofumadores.length; i++) {
                vuelofumadores[i] = 1;
                capacidadfumador++;
            }
            mensajetotalfumador = mensajetotalfumador + puestofumador;
            System.out.println("Su reserva se ha completado tiene " + mensajetotalfumador + " reservador de categoria"
                    + " [FUMADOR]");
            totalfumador = vuelofumadores.length - capacidadfumador;
            System.out.println("La cantidad de puestos de clase [FUMADOR] ahora son " + totalfumador);
        }
    }

    //PROCESO DE CANCELACION CLASE NORMAL
    public void cancelarNormal() {
        while (cancelarnormal == true) {
            System.out.println("Cuantos puestos quiere cancelar");
            int cantidadCancelarNormal = entrada.nextInt();
            if (cantidadCancelarNormal > puestos) {
                System.out.println("No tienes esta cantidad de puestos reservador");
                menuprincipal();
            } else {
                for (int i = vuelonormal.length - cantidadCancelarNormal; i < vuelonormal.length; i++) {
                    vuelonormal[i] = 0;
                    capacidadnormal--;
                }
                puestos = puestos - cantidadCancelarNormal;
                mensajetotalnormal = mensajetotalnormal - cantidadCancelarNormal;
                System.out.println("Su reserva en el area [Normal] se ha cancelado" + " sus reservas actuales son "
                        + mensajetotalnormal);
                totalnormal = totalnormal + cantidadCancelarNormal;
                System.out.println("La cantidad de puestos disponibles ahora son " + totalnormal);
            }
            System.out.println("Quieres hacer alguna otra cancelacion SI[1] No[2]");
            int opOtraCancelacion = entrada.nextInt();
            if (opOtraCancelacion == 1) {
                menucancelar();
            }
            if (opOtraCancelacion == 2) {
                cancelarnormal = false;
                menuprincipal();
            }
        }

    }

    //PROCESO DE CANCELACION CLASE FUMADOR
    public void cancelarFumador() {
        while (cancelarfumador == true) {
            System.out.println("Cuantos puestos quiere cancelar");
            int cantidadCancelarFumador = entrada.nextInt();
            if (cantidadCancelarFumador > puestofumador) {
                System.out.println("No tienes esta cantidad de puestos reservador");
                menuprincipal();
            } else {
                for (int i = vuelofumadores.length - cantidadCancelarFumador; i < vuelofumadores.length; i++) {
                    vuelofumadores[i] = 0;
                    capacidadfumador--;
                }
                puestofumador = puestofumador - cantidadCancelarFumador;
                mensajetotalfumador = mensajetotalfumador - cantidadCancelarFumador;
                System.out.println("Su reserva en el area [Normal] se ha cancelado" + " sus reservas actuales son "
                        + mensajetotalfumador);
                totalfumador = totalfumador + cantidadCancelarFumador;
                System.out.println("La cantidad de puestos disponibles ahora son " + totalfumador);
            }
            System.out.println("Quieres hacer alguna otra cancelacion SI[1] No[2]");
            int opOtraCancelacion = entrada.nextInt();
            if (opOtraCancelacion == 1) {
                menucancelar();
            }
            if (opOtraCancelacion == 2) {
                cancelarfumador = false;
                menuprincipal();
            }
        }
    }

    //TOTAL DE RESERVAS
    public void TotalReservas() {
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("Tu total de reservas en el area [NORMAL] es " + mensajetotalnormal);
        System.out.println("Tu total de reservas en el area [FUMADORES] es " + mensajetotalfumador);
        System.out.println("------------------------------------------------------------------------------");
        menuprincipal();
    }
}
