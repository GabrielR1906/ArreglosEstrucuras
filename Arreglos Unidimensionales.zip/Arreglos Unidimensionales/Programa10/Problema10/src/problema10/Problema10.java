
package problema10;

import java.util.Scanner;

public class Problema10 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Reserva reserva = new Reserva();
        reserva.menuprincipal();
    }
    
}
