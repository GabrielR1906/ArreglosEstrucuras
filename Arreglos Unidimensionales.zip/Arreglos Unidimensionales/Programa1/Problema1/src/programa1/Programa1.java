package programa1;
import java.util.Scanner;
public class Programa1 {

    public static void main(String[] args) {
        Contadores c = new Contadores();
        Scanner entrada = new Scanner(System.in);
        int tamaño;
        System.out.println("Ingrese el tamaño del arreglo");
        tamaño = entrada.nextInt();
        int[] numeros = new int[tamaño];
        for (int i = 0; i < numeros.length; i++) {
            System.out.println("Ingrese el valor para la posicion"+"["+i+"]");
            numeros[i]=entrada.nextInt();
        }
        c.contadores(numeros);
        
        
       
    }
    
}
