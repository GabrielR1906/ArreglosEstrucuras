
package programa1;
public class Contadores {
    int positivos=0;
    int negativos= 0;
    int ceros = 0;
    public void contadores(int X[]){
        for (int i = 0; i < X.length; i++) {
            if (X[i] == 0) {
                ceros++;
            }
            if (X[i]>0) {
                positivos++;
            }
            if (X[i]<0) {
                negativos++;
            }
        }
        System.out.println("-----------------------------------------------------------------------------------------");
        System.out.println("La cantidad de ceros dentro del arreglo es: "+ceros);
        System.out.println("La cantidad de positivos dentro del arreglo es: "+positivos);
        System.out.println("La cantidad de negativos dentro del arreglo es: "+negativos);
        System.out.println("-----------------------------------------------------------------------------------------");
    }
}
