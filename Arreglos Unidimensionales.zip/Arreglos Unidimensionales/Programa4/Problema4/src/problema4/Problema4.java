package problema4;

import java.util.Scanner;

public class Problema4 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Primos primo = new Primos();
        System.out.println("Ingrese el tamaño del arreglo");
        int[] A = new int[entrada.nextInt()];
        
        for (int i = 0; i < A.length; i++) {
            A[i] = i;
        }
        for (int i = 0; i < A.length; i++) {
            System.out.println(A[i]);
        }
        primo.setA(A);
        primo.Generador();
        
    }
}
