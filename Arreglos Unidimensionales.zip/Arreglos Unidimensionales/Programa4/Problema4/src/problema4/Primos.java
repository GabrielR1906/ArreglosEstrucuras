package problema4;

public class Primos {

    int numero;
    int[] A;

    public void Generador() {
        int[] B = new int[A.length];
        for (int i = 0; i < A.length; i++) {
            for (int j = 0; j < A[i]; j++) {
                if (numero > 1) {
                    if (1 == (numero / numero) && (numero)%2 != 2) {
                        B[i] = numero;

                    }
                }
                numero++;
            }
        }
        for (int i = 0; i < B.length; i++) {
            System.out.println(B[i]);
        }
    }

    public void setA(int[] A) {
        this.A = A;
    }
}
