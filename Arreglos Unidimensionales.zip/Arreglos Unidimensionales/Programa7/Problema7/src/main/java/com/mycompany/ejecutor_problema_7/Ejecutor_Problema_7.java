package com.mycompany.ejecutor_problema_7;

import static com.mycompany.ejecutor_problema_7.Metodos.imprimirArreglo;
import static com.mycompany.ejecutor_problema_7.Metodos.insertarValor;
import java.util.Scanner;

public class Ejecutor_Problema_7 {

    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);

        System.out.print("Ingrese el número de elementos del arreglo: ");
        int n = entrada.nextInt();

        int[] arreglo = new int[n];

        System.out.println("Ingrese los elementos del arreglo:");

        for (int i = 0; i < n; i++) {
            System.out.print("Elemento " + (i + 1) + ": ");
            arreglo[i] = entrada.nextInt();
        }

        System.out.print("Ingrese el valor a insertar: ");
        int x = entrada.nextInt();

        System.out.print("Ingrese la posición donde desea insertar el valor: ");
        int k = entrada.nextInt();

        if (k < 0 || k > n) {
            System.out.println("Posición inválida. El valor no se pudo insertar.");
        } else {
            insertarValor(arreglo, x, k);
            System.out.println("Arreglo después de insertar el valor:");
            imprimirArreglo(arreglo);
        }

        
    }
        
    }

