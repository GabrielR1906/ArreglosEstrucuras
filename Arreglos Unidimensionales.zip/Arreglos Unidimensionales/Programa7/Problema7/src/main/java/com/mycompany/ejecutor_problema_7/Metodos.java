package com.mycompany.ejecutor_problema_7;

public class Metodos {
    
    public static void insertarValor(int[] arreglo, int valor, int posicion) {
        int n = arreglo.length;

        // Desplazar los elementos hacia la derecha
        for (int i = n - 1; i > posicion; i--) {
            arreglo[i] = arreglo[i - 1];
        }

        // Insertar el valor en la posición k-ésima
        arreglo[posicion] = valor;
    }

    public static void imprimirArreglo(int[] arreglo) {
        int n = arreglo.length;

        for (int i = 0; i < n; i++) {
            System.out.print(arreglo[i] + " ");
        }

        System.out.println();
    }
}
    
