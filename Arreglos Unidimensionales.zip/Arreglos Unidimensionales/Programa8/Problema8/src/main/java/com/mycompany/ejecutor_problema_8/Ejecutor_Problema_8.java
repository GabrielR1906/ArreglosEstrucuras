package com.mycompany.ejecutor_problema_8;

public class Ejecutor_Problema_8 {

    public static void main(String[] args) {
        
        int cantidadNumeros = 100;
        int[] arreglo = Metodos.calcularCuadrados(cantidadNumeros);

        // Imprimir los resultados
        for (int i = 0; i < cantidadNumeros; i++) {
            System.out.println("El cuadrado de " + (i + 1) + " es: " + arreglo[i]);
        }
    }
}
        
        
  