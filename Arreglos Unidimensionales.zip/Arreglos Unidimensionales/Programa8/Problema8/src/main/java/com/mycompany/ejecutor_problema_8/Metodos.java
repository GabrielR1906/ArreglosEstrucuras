package com.mycompany.ejecutor_problema_8;

public class Metodos {
    
    public static int[] calcularCuadrados(int c) {
        int[] cuadrados = new int[c];

        for (int i = 0; i < c; i++) {
            cuadrados[i] = (i + 1) * (i + 1);
        }

        return cuadrados;
    }
}
    
