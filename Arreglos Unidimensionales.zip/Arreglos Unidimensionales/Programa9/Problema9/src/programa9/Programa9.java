
package programa9;

import java.util.Scanner;

public class Programa9 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Suma s = new Suma();
        
        System.out.println("Ingrese el tamano del arreglo");
        int[]A=new int[entrada.nextInt()];
        
        for (int i = 0; i < A.length; i++) {
            System.out.println("Ingrese el valor de la posicion"+"["+i+"]");
            A[i]=entrada.nextInt();
        }
        s.Sumados(A);
        
    }

}
