
package programa9;

public class Suma {
    
    int pares=0;
    int impares=0;
  
    public void Sumados(int[]A){
        for (int i = 0; i < A.length; i++) {
            if (A[i]%2==0) {
                pares = pares+A[i];
            }else{
                impares=impares+A[i];
            }
        }
        System.out.println("-------------------------------------------------");
        System.out.println("La suma de numeros pares es: "+pares);
        System.out.println("La suma de numeros impares es: "+impares);
        System.out.println("-------------------------------------------------");
    }
    
}
